#ifndef AutoSequenceSeven_H
#define AutoSequenceSeven_H

#include "Commands/CommandGroup.h"
#include "WPILib.h"

class AutoSequenceSeven: public CommandGroup
{
public:
	AutoSequenceSeven();
};

#endif
