This code works, probably
Update: 
1. Added driving backward in auto
1. Added driving with ultra
