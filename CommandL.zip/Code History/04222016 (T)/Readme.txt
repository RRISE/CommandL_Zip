This code has Testing programs that are very impressive.
It does acurate turn and drive staight using both Ultrasonic and encoder.