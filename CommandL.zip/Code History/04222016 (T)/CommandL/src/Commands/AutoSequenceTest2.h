#ifndef AutoSequenceTest2_H
#define AutoSequenceTest2_H

#include "Commands/CommandGroup.h"
#include "WPILib.h"

class AutoSequenceTest2: public CommandGroup
{
public:
	AutoSequenceTest2();
};

#endif
