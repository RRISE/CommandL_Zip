#ifndef AutoSequenceTest1_H
#define AutoSequenceTest1_H

#include "Commands/CommandGroup.h"
#include "WPILib.h"

class AutoSequenceTest1: public CommandGroup
{
public:
	AutoSequenceTest1();
};

#endif
