#include "AutoSequenceTest3.h"
#include "Commands/Turn.h"


//encoder forward
AutoSequenceTest3::AutoSequenceTest3()
{
	SmartDashboard::PutString("Auto", "AutoSequenceTest3");
	//AddSequential(new AutoMove(0.5, 1.0, 0, 1.0, true));
	double speed = Preferences::GetInstance()->GetFloat("AT3_Speed", 0.7);
	double target = Preferences::GetInstance()->GetFloat("AT3_Target", 100);
	double kP = Preferences::GetInstance()->GetFloat("AT3_kP", 1.0);
	AddSequential(new Turn(target, kP));
	//double speed, double d_target, double a_target, double kP)
}
