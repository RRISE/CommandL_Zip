#ifndef AutoSequenceTest3_H
#define AutoSequenceTest3_H

#include "Commands/CommandGroup.h"
#include "WPILib.h"

class AutoSequenceTest3: public CommandGroup
{
public:
	AutoSequenceTest3();
};

#endif
