#include "AutoSequenceTest1.h"
#include "Commands/AutoMove.h"
#include "Commands/Turn.h"


//encoder forward
AutoSequenceTest1::AutoSequenceTest1()
{
	SmartDashboard::PutString("Auto", "AutoSequenceTest1");
	//AddSequential(new AutoMove(0.5, 1.0, 0, 1.0, true));
	double speed1 = Preferences::GetInstance()->GetFloat("AT1_Speed1", 1.0);
	double speed2 = Preferences::GetInstance()->GetFloat("AT1_Speed2", 0.7);
	double enc_target = Preferences::GetInstance()->GetFloat("AT1_Target1", 79);
	double ultra_target = Preferences::GetInstance()->GetFloat("AT1_Target2", 1.0);
	double ultra_target2 = Preferences::GetInstance()->GetFloat("AT1_Target3", 1.5);

	double AT3_Target = Preferences::GetInstance()->GetFloat("AT3_Target", 240);
	double turn_kP = Preferences::GetInstance()->GetFloat("AT3_kP", 1.0);

	double kP = Preferences::GetInstance()->GetFloat("AT1_kP", 1.0);
	AddSequential(new AutoMove(speed1, enc_target, 0, kP));
	AddSequential(new AutoMove(speed2, ultra_target, 0, kP, true));
	AddSequential(new Turn(AT3_Target, turn_kP));
	AddSequential(new AutoMove(speed1, ultra_target2, 0, kP, true));
	//double speed, double d_target, double a_target, double kP)
}
