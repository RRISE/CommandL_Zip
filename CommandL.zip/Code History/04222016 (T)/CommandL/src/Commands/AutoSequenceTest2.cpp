#include "AutoSequenceTest2.h"
#include "Commands/AutoMove.h"


//encoder forward
AutoSequenceTest2::AutoSequenceTest2()
{
	SmartDashboard::PutString("Auto", "AutoSequenceTest1");
	//AddSequential(new AutoMove(0.5, 1.0, 0, 1.0, true));
	double speed = Preferences::GetInstance()->GetFloat("AT1_Speed", 0.7);
	double target = Preferences::GetInstance()->GetFloat("AT1_Target", 1.0);
	double kP = Preferences::GetInstance()->GetFloat("AT1_kP", 1.0);
	AddSequential(new AutoMove(speed, target, 0, kP, true));
	//double speed, double d_target, double a_target, double kP)
}
