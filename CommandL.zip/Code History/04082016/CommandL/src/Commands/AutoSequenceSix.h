#ifndef AutoSequenceSix_H
#define AutoSequenceSix_H

#include "Commands/CommandGroup.h"
#include "WPILib.h"

class AutoSequenceSix: public CommandGroup
{
public:
	AutoSequenceSix();
};

#endif
