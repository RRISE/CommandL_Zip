#ifndef AutoSequenceThree_H
#define AutoSequenceThree_H

#include "Commands/CommandGroup.h"
#include "WPILib.h"

class AutoSequenceThree: public CommandGroup
{
public:
	AutoSequenceThree();
};

#endif
