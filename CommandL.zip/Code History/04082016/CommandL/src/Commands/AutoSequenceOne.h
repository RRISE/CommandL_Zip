#ifndef AutoSequenceOne_H
#define AutoSequenceOne_H

#include "Commands/CommandGroup.h"
#include "WPILib.h"

class AutoSequenceOne: public CommandGroup
{
public:
	AutoSequenceOne();
};

#endif
