#include "AutoSequenceThree.h"



/*****
 * this auto is no code duh
 */
AutoSequenceThree::AutoSequenceThree()
{

	SmartDashboard::PutString("Auto", "AutoSequenceThree");

	//chill

}
