#ifndef AutoSequenceFive_H
#define AutoSequenceFive_H

#include "Commands/CommandGroup.h"
#include "WPILib.h"

class AutoSequenceFive: public CommandGroup
{
public:
	AutoSequenceFive();
};

#endif
