#ifndef AutoSequenceFour_H
#define AutoSequenceFour_H

#include "Commands/CommandGroup.h"
#include "WPILib.h"

class AutoSequenceFour: public CommandGroup
{
public:
	AutoSequenceFour();
};

#endif
