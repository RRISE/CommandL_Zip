#ifndef AutoSequenceTwo_H
#define AutoSequenceTwo_H

#include "Commands/CommandGroup.h"
#include "WPILib.h"

class AutoSequenceTwo: public CommandGroup
{
public:
	AutoSequenceTwo();
};

#endif
