This code works. 
Used in Match 32+